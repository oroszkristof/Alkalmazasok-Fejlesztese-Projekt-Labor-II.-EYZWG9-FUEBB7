import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="card" style={{ textAlign: 'center', padding: '4rem 2rem', marginTop: '2rem' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>
        Találd meg a tökéletes pihenést!
      </h1>
      <p style={{ fontSize: '1.2rem', color: 'var(--text-muted)', marginBottom: '2rem', maxWidth: '600px', margin: '0 auto 2rem auto' }}>
        Fedezz fel csodálatos szálláshelyeket a legjobb áron. Legyen szó egy romantikus hétvégéről vagy egy családi nyaralásról, nálunk biztosan megtalálod, amit keresel.
      </p>
      
      <div style={{ display: 'flex', gap: '15px', justifyContent: 'center' }}>
        <button className="btn btn-primary" onClick={() => navigate('/szallasok')}>
          Szállások böngészése
        </button>
        <button className="btn" style={{ backgroundColor: 'transparent', border: '1px solid var(--border-color)', color: 'var(--text-main)' }} onClick={() => navigate('/login')}>
          Belépés a fiókba
        </button>
      </div>
    </div>
  );
}