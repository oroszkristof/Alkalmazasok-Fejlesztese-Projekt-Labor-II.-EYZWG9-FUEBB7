import React from 'react';

export default function Contact() {
  return (
    <div className="card" style={{ maxWidth: '600px', margin: '2rem auto' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        Lépj velünk kapcsolatba! 
      </h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '2rem' }}>
        {/* Elérhetőségek */}
        <div style={{ textAlign: 'center', color: 'var(--text-muted)', lineHeight: '1.8' }}>
          <p style={{ margin: '5px 0' }}>📍 <strong>Cím:</strong> 1051 Budapest, Példa utca 12.</p>
          <p style={{ margin: '5px 0' }}>📞 <strong>Telefon:</strong> +36 1 234 5678</p>
          <p style={{ margin: '5px 0' }}>📧 <strong>Email:</strong> info@szallasportal.hu</p>
        </div>

        {/* Üzenetküldő űrlap */}
        <form onSubmit={(e) => { e.preventDefault(); alert('Üzenet sikeresen elküldve! (Ez csak egy bemutató)'); }} style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1.5rem' }}>
          <label>
            <strong>Neved</strong>
            <input type="text" className="input-field" placeholder="Pl.: Kovács János" required />
          </label>
          
          <label>
            <strong>Email címed</strong>
            <input type="email" className="input-field" placeholder="pelda@email.com" required />
          </label>
          
          <label>
            <strong>Üzenet</strong>
            <textarea 
              className="input-field" 
              rows="5" 
              placeholder="Miben segíthetünk?"
              style={{ resize: 'vertical', fontFamily: 'inherit' }}
              required
            ></textarea>
          </label>
          
          <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
            Üzenet küldése
          </button>
        </form>
      </div>
    </div>
  );
}