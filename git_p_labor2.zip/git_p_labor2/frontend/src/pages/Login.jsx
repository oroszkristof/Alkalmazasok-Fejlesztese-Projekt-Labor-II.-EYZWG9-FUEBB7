import React, { useState } from 'react';

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="card" style={{ maxWidth: '400px', margin: '0 auto', marginTop: '2rem' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '1.5rem' }}>
        {isLogin ? 'Üdv újra nálunk! 👋' : 'Hozd létre a fiókod 📝'}
      </h2>
      
      <form onSubmit={(e) => e.preventDefault()}>
        {!isLogin && (
          <label>
            <strong>Teljes név</strong>
            <input type="text" className="input-field" placeholder="Pl.: Kovács János" />
          </label>
        )}
        
        <label>
          <strong>Email cím</strong>
          <input type="email" className="input-field" placeholder="pelda@email.com" />
        </label>
        
        <label>
          <strong>Jelszó</strong>
          <input type="password" className="input-field" placeholder="••••••••" />
        </label>
        
        <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '15px' }}>
          {isLogin ? 'Bejelentkezés' : 'Regisztráció'}
        </button>
      </form>

      <div style={{ marginTop: '25px', textAlign: 'center', borderTop: '1px solid var(--border-color)', paddingTop: '20px' }}>
        <span style={{ color: 'var(--text-muted)', fontSize: '0.95rem' }}>
          {isLogin ? 'Még nincs fiókod?' : 'Már van fiókod?'}
        </span>
        <button 
          type="button"
          onClick={() => setIsLogin(!isLogin)} 
          style={{ 
            background: 'none', border: 'none', color: 'var(--primary)', 
            fontWeight: 'bold', cursor: 'pointer', marginLeft: '8px', fontSize: '0.95rem'
          }}
        >
          {isLogin ? 'Regisztrálj!' : 'Jelentkezz be!'}
        </button>
      </div>
    </div>
  );
}