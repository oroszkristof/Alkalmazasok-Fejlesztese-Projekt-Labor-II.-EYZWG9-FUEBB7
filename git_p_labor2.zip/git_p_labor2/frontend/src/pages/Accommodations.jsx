import React, { useState, useEffect } from 'react';

// 15 darab szállásnév
const accommodationNames = [
  "Napfény Terasz Apartman", 
  "Kék Hullám Vendégház", 
  "Erdei Menedék Rönkház", 
  "Panoráma Boutique Hotel", 
  "Aranyhíd Panzió", 
  "Tóparti Pihenő", 
  "Hegyi Kristály Vendégház", 
  "Békés Sziget Apartman", 
  "Vadvirág Családi Panzió", 
  "Ékszerdoboz Vendégház", 
  "Csillagfény Wellness Hotel", 
  "Harmónia Apartmanház", 
  "Nyugalom Szigete Kúria", 
  "Levendula Provance Vendégház", 
  "Családi Fészek Apartman"
];

// 15 darab  leírás
const accommodationDescriptions = [
  "Kiváló elhelyezkedésű apartman, ahonnan csodálatos kilátás nyílik a környékre. Ideális párok számára, akik romantikus kikapcsolódásra vágynak, modern kényelemmel fűszerezve.",
  "Tágas és világos vendégház, tökéletes választás nagycsaládosoknak. Jól felszerelt konyha, fedett terasz és hatalmas, parkosított kert várja a pihenni vágyókat.",
  "Erdei környezetben található, csendes rönkház, távol a város zajától. Kályha és saját szauna gondoskodik a meghitt hangulatról a hidegebb napokon is.",
  "Elegáns és modern boutique hotel a belváros szívében. Sétatávolságra a legfőbb látványosságoktól, múzeumoktól és a legkiválóbb helyi éttermektől.",
  "Közvetlen vízparti kapcsolattal rendelkező panzió, saját stéggel és ingyenes csónakbérlési lehetőséggel. A horgászat és a vízi sportok szerelmeseinek kifejezetten ajánljuk.",
  "Hangulatos tóparti pihenő, panorámás terasszal és privát jakuzzival. Ébredjen minden reggel a madárcsicsergésre, és gyönyörködjön a lenyűgöző naplementében.",
  "Hegyi kristálytiszta levegő és izgalmas túraútvonalak közvetlenül a vendégház kapujában. Az aktív pihenésre vágyóknak és a természetkedvelőknek a legjobb választás.",
  "Igazi békés sziget a rohanó hétköznapokban. Letisztult design, extra kényelmes ágyak, okosotthon funkciók és maximális diszkréció jellemzi ezt a prémium apartmant.",
  "Családias hangulatú panzió, ahol a háziasszony minden reggel friss, házi pékáruval és termelői finomságokkal várja a vendégeket. Gyermekbarát szolgáltatásokkal felszerelve.",
  "Műemlék jellegű épületben kialakított ékszerdoboz, tele antik bútorokkal és történelmi bájjal. Valódi időutazás a 21. századi kényelem és luxus feladása nélkül.",
  "Minden igényt kielégítő wellness hotel, korlátlan medence-, szauna- és gőzkabinha-sználattal. Tökéletes helyszín a teljes testi és lelki feltöltődéshez a rohanó hétköznapok után.",
  "Harmonikus színekkel és természetes anyagokkal berendezett apartmanház. A hatalmas panorámaablakoknak köszönhetően a terek egész nap fürdenek a természetes napfényben.",
  "Főúri kényelem egy gyönyörűen, korhűen felújított vidéki kúriában. Hatalmas ősfás park és egy több száz éves saját borospince teszi igazán felejthetetlenné az ittlétet.",
  "Provance-i stílusú, levendulaillatú vendégház, igazi vidéki romantikával. Kézműves reggeli kosár, friss levegő és tökéletes, zavartalan béke várja az ide látogatókat.",
  "Otthonos családi fészek, ahol a legkisebbektől a nagyszülőkig minden generáció megtalálja a számítását. Külön játszószoba a gyerekeknek és kényelmes grillterasz a felnőtteknek."
];

// Adatok generálása az egyedi nevek és leírások felhasználásával
const generateMockData = () => {
  return Array.from({ length: 15 }, (_, i) => ({
    id: i + 1,
    name: accommodationNames[i], 
    location: ["Balatonfüred", "Siófok", "Budapest", "Hévíz", "Eger"][i % 5],
    price: `${15000 + (i * 1500)} Ft / éj`,
    capacity: `${(i % 4) + 2} fő`,
    rating: (4 + (Math.random() * 0.9)).toFixed(1) + " / 5",
    description: accommodationDescriptions[i], // <-- Itt húzzuk be a fenti listából az egyedi leírásokat!
    images: Array.from({ length: 5 }, (_, j) => `https://picsum.photos/seed/${i * 5 + j}/600/300`)
  }));
};

// ... INNENTŐL LENT MARAD MINDEN UGYANAZ (AccommodationCard és Accommodations komponens) ...

// 2. Létrehozunk egy "SzállásKártya" komponenst
// Így minden egyes kártyának lehet saját, független időzítője
const AccommodationCard = ({ acc, onDelete }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    // Beállítunk egy időzítőt, ami 5000 ezredmásodpercenként (5mp) lefut
    const timer = setInterval(() => {
      setCurrentImageIndex((prevIndex) => (prevIndex + 1) % acc.images.length);
    }, 5000);

    // Nagyon fontos: Amikor a kártya eltűnik (pl. töröljük), leállítjuk az időzítőt!
    return () => clearInterval(timer);
  }, [acc.images.length]);

  return (
    <div className="card">
      <h3 style={{ fontSize: '1.4rem' }}>{acc.name}</h3>
      
      {/* 4 mondatos leírás */}
      <p style={{ color: 'var(--text-muted)', lineHeight: '1.6', margin: '15px 0', fontSize: '0.95rem' }}>
        {acc.description}
      </p>

      <ul style={{ listStyleType: 'none', padding: 0, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px', marginTop: '1rem' }}>
        <li>📍 <strong>Helyszín:</strong> {acc.location}</li>
        <li>💰 <strong>Ár:</strong> {acc.price}</li>
        <li>👥 <strong>Kapacitás:</strong> {acc.capacity}</li>
        <li>⭐ <strong>Értékelés:</strong> {acc.rating}</li>
      </ul>

      {/* Automatikusan váltakozó Képgaléria */}
      <div style={{ marginTop: '20px' }}>
        <img 
          src={acc.images[currentImageIndex]} 
          alt={`${acc.name} - Kép ${currentImageIndex + 1}`} 
          style={{ 
            width: '100%', 
            height: '280px', 
            objectFit: 'cover', 
            borderRadius: '10px',
            transition: 'all 0.4s ease-in-out' // Finom áttűnés váltáskor
          }} 
          loading="lazy"
        />
        
        {/* Kis navigációs pöttyök a kép alatt */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '10px', marginTop: '12px' }}>
          {acc.images.map((_, idx) => (
            <div 
              key={idx}
              onClick={() => setCurrentImageIndex(idx)} // Kattintásra is lehessen váltani
              style={{
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                backgroundColor: currentImageIndex === idx ? 'var(--primary)' : 'var(--border-color)',
                cursor: 'pointer',
                transition: 'background-color 0.3s ease'
              }}
            />
          ))}
        </div>
      </div>

      <div style={{ marginTop: '25px', display: 'flex', gap: '12px' }}>
        <button className="btn btn-warning">Módosítás</button>
        <button className="btn btn-danger" onClick={() => onDelete(acc.id)}>Törlés</button>
      </div>
    </div>
  );
};

// 3. A fő Szállások oldal, ami listázza a kártyákat
export default function Accommodations() {
  const [accommodations, setAccommodations] = useState(generateMockData());

  const handleDelete = (id) => {
    setAccommodations(accommodations.filter(acc => acc.id !== id));
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h2>Elérhető szállások ({accommodations.length})</h2>
        <button className="btn btn-primary">+ Új szállás rögzítése</button>
      </div>

      <div>
        {accommodations.map((acc) => (
          // Itt hívjuk meg az új kártya komponenst minden szállásra
          <AccommodationCard key={acc.id} acc={acc} onDelete={handleDelete} />
        ))}
      </div>
    </div>
  );
}