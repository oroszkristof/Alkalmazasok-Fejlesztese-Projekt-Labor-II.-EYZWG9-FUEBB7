import React from 'react';

export default function Register() {
  return (
    <div className="card" style={{ maxWidth: '400px', margin: '0 auto' }}>
      <h2>Regisztráció 📝</h2>
      <form onSubmit={(e) => e.preventDefault()}>
        <label>
          <strong>Név</strong>
          <input type="text" className="input-field" placeholder="Pl.: Kovács János" />
        </label>
        
        <label>
          <strong>Email cím</strong>
          <input type="email" className="input-field" placeholder="pelda@email.com" />
        </label>
        
        <label>
          <strong>Jelszó</strong>
          <input type="password" className="input-field" placeholder="••••••••" />
        </label>
        
        <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '10px' }}>
          Regisztrálok
        </button>
      </form>
    </div>
  );
}