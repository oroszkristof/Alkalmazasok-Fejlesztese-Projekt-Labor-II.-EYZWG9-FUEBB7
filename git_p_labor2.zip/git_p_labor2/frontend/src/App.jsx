import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Accommodations from './pages/Accommodations';
import Contact from './pages/Contact';

// 1. Itt importáljuk be az SVG ikont!
import logoIcon from './ikon.svg';

export default function App() {
  const navLinkClass = ({ isActive }) => isActive ? "nav-link active" : "nav-link";

  return (
    <BrowserRouter>
      <div>
        <nav className="navbar">
          {/* Bal oldal: Logó és Szöveg */}
          <div className="logo-container" style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            {/* 2. Itt jelenítjük meg az ikont */}
            <img src={logoIcon} alt="SzállásPortál Logó" style={{ height: '35px', width: 'auto' }} />
            <span>SzállásPortál</span>
          </div>

          {/* Jobb oldal: Menüpontok */}
          <div className="nav-links">
            <NavLink to="/" className={navLinkClass}>Főoldal</NavLink>
            <NavLink to="/szallasok" className={navLinkClass}>Szállások</NavLink>
            <NavLink to="/kapcsolat" className={navLinkClass}>Kapcsolat</NavLink>
            <NavLink to="/login" className={navLinkClass}>Belépés</NavLink>
          </div>
        </nav>

        <main className="page-container">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/szallasok" element={<Accommodations />} />
            <Route path="/kapcsolat" element={<Contact />} />
            <Route path="/login" element={<Login />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}